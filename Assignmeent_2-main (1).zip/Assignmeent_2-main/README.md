# Assignmeent_2
This is assignment _2 for dice camp  
